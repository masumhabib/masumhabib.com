% Subfigures using Inkscape

clear all;

%% compute power from voltage and current
f = 50;                 % grid frequency
Vm = 220*sqrt(2);       % grid peak voltage
Im = 2*sqrt(2);         % peak current
phi = pi/5;             % current phase

t = [0:0.0001:3/f];     % time sequence
th = 2*pi*f*t;
V = Vm*sin(th);         % instantaneous voltage
I = Im*sin(th - phi);   % instantaneous current
P = V.*I;               % instantaneous power
Prms = Vm*Im/2*ones(size(P));% RMS power 

%% plot voltage
figure, plot(t*1E3, V);

opt = [];
opt.BoxDim = [6,2];
opt.XLabel = 'Time, t (ms)';   
opt.YLabel = 'Voltage, V (V)'; 
opt.FileName = 'plotV.eps'; 

setPlotProp(opt); % set properties and export figure

%% plot current
figure, plot(t*1E3, I);

opt = [];
opt.BoxDim = [6,2];
opt.XLabel = 'Time, t (ms)';  
opt.YLabel = 'Current, I (A)';
opt.FileName = 'plotI.eps'; 

setPlotProp(opt); % set properties and export figure

%% plot power
figure;
plot(t*1E3, P);
hold on;
plot(t*1E3, Prms);
hold off;

opt = [];
opt.BoxDim = [6,2];
opt.XLabel = 'Time, t (ms)';
opt.YLabel = 'Power, P (W)';
opt.YLim = [-1000, 1000];
opt.LineStyle = {'-', '--'};
opt.Legend = {'Instantaneous', 'RMS'};
opt.LegendLoc = 'SouthEast';
opt.FileName = 'plotP.eps'; 

setPlotProp(opt);  % set properties and export figure
